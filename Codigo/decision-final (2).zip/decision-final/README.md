# DF · Decisión Final (Defendiendo la justicia. Un píxel a la vez.)

Juego educativo de Educación Ciudadana: 10 casos, 10 preguntas por caso (100 en total), 20 segundos por pregunta, un desafío final por nivel, personaje personalizable y manual integrado.
HTML + CSS + JavaScript puro, sin dependencias para jugar.

---

## 1. Cómo ejecutarlo

**Opción rápida:** abrí `index.html` con doble clic (Chrome / Edge).

**Recomendado (cualquier navegador):** serví la carpeta con un servidor local:

```bash
npx http-server -p 8080 -c-1 .      # o:  python3 -m http.server 8080
```
y abrí <http://localhost:8080>.

El progreso, el personaje y la configuración se guardan en el navegador (`localStorage`).
Para empezar de cero: borrá los datos del sitio en el navegador.

## 2. Cómo probarlo

Pruebas automáticas de los 12 casos obligatorios (Chromium con reloj simulado, ~2 min):

```bash
npm install
npx playwright install chromium     # solo la primera vez
npm test
```

Casos cubiertos: completar las 10 preguntas · pregunta que llega a 0 s · intentar responder después del tiempo · flechas dentro y fuera del cuestionario · desafío final + redirección automática · perder un nivel y que se desbloquee el siguiente · botón «Siguiente nivel» · accesorios que se mantienen · manual · nivel 10 y pantalla final · sin acciones duplicadas (y URLs inválidas) · imágenes, estilos, fuentes y consola sin errores.

## 3. Cómo se juega (resumen)

`Portada → Registro → Menú → Selección de nivel → Título → Descripción → Información del caso (3 carpetas) → Juicio → 10 preguntas (20 s c/u) → Desafío final (3 palabras) → Resultado → (8 s) → Selección de nivel`

* **Preguntas:** 4 opciones; mouse, flechas/WASD + Enter, o teclas 1-4. Una sola respuesta por pregunta. Correcta = 100 pts + bonus por rapidez (hasta 40). Tiempo agotado = «sin responder».
* **Pregunta oficial:** la 1.ª de cada nivel es la del PDF; al responderla se muestra la **devolución** del caso.
* **Flechas:** ← vuelve y → avanza (también con el teclado). Se **deshabilitan** durante las preguntas y el desafío final.
* **Ganar:** ≥ 7 correctas y ≥ 2 palabras. **Terminar** un nivel (ganado o perdido) **desbloquea el siguiente**; nunca se vuelve a bloquear.
* **Resultado:** botones *Siguiente nivel* (en el 10: *Ver final*), *Reintentar nivel* y *Niveles*; si no se toca nada, vuelve solo a *Selección de nivel* a los 8 s.
* **Vestí a tu personaje:** 12 categorías y 40 prendas del prototipo. Una prenda por categoría, tocar de nuevo para sacarla, bufanda y collar se excluyen. Se desbloquean al terminar niveles.

Todas las reglas se configuran en un solo lugar: `DF.rules` en `js/data/niveles.js` (segundos, puntajes, aciertos mínimos, espera de la redirección, etc.).

## 4. Estructura

```
index.html                 Portada
pages/                     Una pantalla por archivo
  registro, menu, config, soporte, ranking, manual, vestir,
  niveles, nivel-titulo, nivel-desc, caso, juicio,
  desafio (preguntas), palabra (desafío final), resultado, fin (pantalla final)
css/
  base.css                 Fuentes, colores, escenario 1280x720
  components.css           Botones, flechas, campos, barra de scroll, toasts
  screens.css              Menú, niveles, título, caso, manual, ranking…
  game.css                 Vestuario, tribunal, preguntas, desafío, resultado, final
js/core/                   Módulos reutilizables
  store.js                 Guardado (localStorage) + migración de partidas viejas
  progress.js              Progresión: estados, desbloqueo, mejor puntaje, prendas
  boot.js                  Arranque, protección de pantallas, NAVEGACIÓN con flechas
  timer.js                 Temporizador de cuenta regresiva (uno por pregunta)
  scrollbar.js             Barra de scroll del prototipo
  sprites.js               Dibuja personaje, prendas, juez, fiscal y tribunal (SVG)
  i18n.js, audio.js, stage.js   Idioma, sonidos, escalado/brillo
js/data/                   Solo datos (sin lógica)
  niveles.js               10 casos, 100 preguntas, palabras, devoluciones y DF.rules
  vestuario.js             Pixel-art (GENERADO por tools/build_sprites.py)
  manual.js                Texto del manual
  niveles-previos.js       Casos de la versión anterior (no se carga)
js/pages/                  Un script por pantalla
tools/build_sprites.py     Generador del pixel-art (python3 tools/build_sprites.py)
tests/e2e.js               Pruebas funcionales (npm test)
assets/                    icons/, img/ (fondo, logo), fonts/
```

## 5. Agregar o editar contenido

* **Preguntas:** `js/data/niveles.js` → `Q(enunciado, A, B, C, D, 'letraCorrecta', oficial)`.
* **Palabras del desafío final:** `DF.palabras` (mismo archivo).
* **Prendas:** editar `tools/build_sprites.py` y ejecutarlo (regenera `js/data/vestuario.js`).
* **Manual:** `js/data/manual.js` (los números se leen de `DF.rules`).

## 6. Notas sobre el contenido

* El PDF «Casos definitivos» trae **una pregunta por caso** (10 en total). Para llegar a 10 por nivel, las otras 9 de cada nivel se redactaron **solo con los hechos del propio caso** (descripción, testimonios, pruebas, denuncia y devolución del PDF), sin agregar información externa. La pregunta oficial está marcada con `oficial:true` y mantiene su orden A-D; en las demás se mezclan las opciones en cada partida.
* El personaje, las prendas, el juez, el fiscal y el tribunal se recrearon en pixel-art a partir de las capturas del prototipo, porque el ZIP no traía esos archivos de imagen. Si se consiguen los PNG originales, se pueden reemplazar en `js/core/sprites.js` sin tocar la lógica.
* El texto largo del manual está en español; con el idioma en inglés, la interfaz se traduce y el manual se muestra en español.

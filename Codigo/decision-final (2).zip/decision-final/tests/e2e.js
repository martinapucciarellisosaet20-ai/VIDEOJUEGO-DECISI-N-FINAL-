/* =========================================================
   tests/e2e.js · Pruebas funcionales de punta a punta
   Ejecuta los 12 casos obligatorios en Chromium (Playwright)
   con un reloj simulado (los 20 s se adelantan sin esperar).

   Uso:   npm install   (una vez)   →   npm test
   ========================================================= */
const { chromium } = require('playwright');
const path = require('path');
const assert = require('assert');

const ROOT = 'file://' + path.resolve(__dirname, '..');
const KEY = 'df_decision_final_v1';
const results = [];

/* ---------- utilidades ---------- */
async function open(browser, seed){
  const context = await browser.newContext({ viewport:{ width:1280, height:720 } });
  await context.clock.install();
  const page = await context.newPage();
  page.errors = [];
  page.on('pageerror', e => page.errors.push(String(e)));
  page.on('console', m => { if(m.type() === 'error') page.errors.push(m.text()); });
  page.on('requestfailed', r => page.errors.push('No cargó: ' + r.url()));
  await page.goto(ROOT + '/index.html');
  await page.evaluate(([k, s]) => { localStorage.setItem(k, JSON.stringify(s)); sessionStorage.clear(); }, [KEY, seed || { user:'Tester', email:'t@test.com' }]);
  return { context, page };
}
const go = (page, p) => page.goto(ROOT + '/pages/' + p);
const tick = (page, ms) => page.clock.runFor(ms);
const url = page => page.url().split('/pages/')[1] || page.url();
const state = page => page.evaluate(k => JSON.parse(localStorage.getItem(k)), KEY);
const played = n => { const o = {}; for(let i = 1; i <= n; i++) o[i] = { played:true, passed:true, score:1000, stars:2, attempts:1 }; return o; };

/* Responde la pregunta visible. mode: 'right' | 'wrong' */
async function answer(page, mode){
  const idx = await page.evaluate(m => {
    const n = +new URLSearchParams(location.search).get('n');
    const text = document.getElementById('q-text').textContent;
    const q = DF.levels[n - 1].preguntas.find(x => x.q === text);
    const ok = q.o[q.c];
    const btns = [...document.querySelectorAll('.q-opt')];
    const i = btns.findIndex(b => b.textContent.slice(3).trim() === ok);
    return m === 'right' ? i : (i + 1) % 4;
  }, mode);
  await page.click('.q-opt >> nth=' + idx);
  await tick(page, 5300);                         // espera la corrección (máx. 5,2 s en la oficial)
}
async function playQuiz(page, n, mode){
  await go(page, 'desafio.html?n=' + n);
  for(let i = 0; i < 10; i++) await answer(page, typeof mode === 'function' ? mode(i) : mode);
  await page.waitForURL(/palabra\.html/);
}
/* Desafío final: 'right' adivina las 3 palabras; 'wrong' agota los intentos */
async function playWords(page, n, mode){
  const words = await page.evaluate(n => DF.levels[n - 1].palabras.map(p => p.respuesta), n);
  for(const w of words){
    const tries = mode === 'right' ? [w] : Array(6).fill('Z'.repeat(w.length));
    for(const tr of tries){
      await page.keyboard.type(tr.toLowerCase());
      await page.keyboard.press('Enter');
      await tick(page, w.length * 110 + 600);
    }
    await tick(page, 2600);
  }
  await page.waitForURL(/resultado\.html/);
}

async function test(name, fn){
  const browser = await chromium.launch();
  try { await fn(browser); results.push(['✔', name]); }
  catch(e){ results.push(['✘', name + '\n     ' + (e && e.message || e)]); }
  finally { await browser.close(); }
}

/* ---------- casos ---------- */
(async () => {

await test('1. Completar las 10 preguntas de un nivel', async b => {
  const { page } = await open(b);
  await go(page, 'desafio.html?n=1');
  const seen = new Set();
  for(let i = 0; i < 10; i++){
    seen.add(await page.textContent('#q-text'));
    assert.strictEqual(await page.textContent('#q-meta').then(t => t.split('·')[0].trim()), 'Pregunta ' + (i + 1) + ' de 10');
    await answer(page, 'right');
  }
  await page.waitForURL(/palabra\.html\?n=1/);
  assert.strictEqual(seen.size, 10, 'deben verse 10 preguntas distintas');
  const quiz = await page.evaluate(() => JSON.parse(sessionStorage.getItem('df_quiz')));
  assert.strictEqual(quiz.correct, 10);
  assert.deepStrictEqual(page.errors, []);
});

await test('2. Dejar que una pregunta llegue a 0 segundos', async b => {
  const { page } = await open(b);
  await go(page, 'desafio.html?n=1');
  assert.strictEqual(await page.textContent('#q-secs'), '20');
  await tick(page, 10050);
  assert.strictEqual(await page.textContent('#q-secs'), '10', 'el contador baja de a 1 segundo');
  await tick(page, 10050);
  assert.strictEqual(await page.textContent('#q-secs'), '0');
  assert.strictEqual(await page.locator('.q-opt.right').count(), 1, 'se muestra la correcta');
  assert.strictEqual(await page.locator('.q-opt.wrong').count(), 0);
  assert.strictEqual(await page.locator('.q-opt:disabled').count(), 4, 'opciones bloqueadas');
  await tick(page, 5300);
  assert.match(await page.textContent('#q-meta'), /Pregunta 2 de 10/, 'pasa sola a la siguiente');
  assert.strictEqual(await page.textContent('#q-secs'), '20', 'el temporizador se reinicia');
});

await test('3. Intentar responder después de que se termine el tiempo', async b => {
  const { page } = await open(b);
  await go(page, 'desafio.html?n=1');
  await tick(page, 20100);
  const before = await page.textContent('#q-meta');
  await page.evaluate(() => document.querySelectorAll('.q-opt').forEach(x => x.click()));
  await page.keyboard.press('1'); await page.keyboard.press('Enter');
  assert.strictEqual(await page.textContent('#q-meta'), before, 'no suma puntos');
  assert.strictEqual(await page.locator('.q-opt.wrong').count(), 0, 'no registra otra respuesta');
  await tick(page, 30000);                         // si quedara un temporizador viejo, saltaría preguntas
  const q = await page.textContent('#q-meta');
  assert.match(q, /Pregunta 3 de 10/, 'avanza exactamente de a una pregunta: ' + q);
  // termina el cuestionario con todo sin responder y se registra
  for(let i = 3; i <= 10; i++) await tick(page, 22300 + 5300);
  await page.waitForURL(/palabra\.html/);
  const quiz = await page.evaluate(() => JSON.parse(sessionStorage.getItem('df_quiz')));
  assert.strictEqual(quiz.unanswered, 10);
});

await test('4. Flechas dentro y fuera del cuestionario', async b => {
  const { page } = await open(b);
  // fuera: avanzar y volver con las flechas (y con las teclas ← →)
  await go(page, 'nivel-titulo.html?n=1');
  await page.click('.btn-next', { force:true }); await page.waitForURL(/nivel-desc\.html\?n=1/);
  await page.keyboard.press('ArrowRight'); await page.waitForURL(/caso\.html\?n=1/);
  assert.ok(await page.locator('#btn-empezar.disabled').count(), 'no avanza sin leer las carpetas');
  await page.keyboard.press('ArrowRight'); await tick(page, 300);
  assert.match(url(page), /^caso\.html/);
  await page.keyboard.press('ArrowLeft'); await page.waitForURL(/nivel-desc\.html\?n=1/);
  // dentro del cuestionario: deshabilitadas
  await go(page, 'desafio.html?n=1');
  assert.ok(await page.locator('.btn-back.nav-locked').count(), 'flecha bloqueada');
  assert.strictEqual(await page.getAttribute('.btn-back', 'href'), null);
  await page.keyboard.press('ArrowLeft'); await tick(page, 300);
  await page.click('.btn-back', { force:true }); await tick(page, 300);
  assert.match(url(page), /^desafio\.html/, 'no se puede salir del cuestionario');
  assert.strictEqual(await page.locator('.q-opt.sel').count(), 1, 'las flechas del teclado eligen opciones');
  // al terminar, la navegación vuelve a funcionar (pantalla de resultado / niveles)
  for(let i = 0; i < 10; i++) await answer(page, 'right');
  await page.waitForURL(/palabra\.html/);
  assert.ok(await page.locator('.btn-back.nav-locked').count(), 'también bloqueada en el desafío final');
  await playWords(page, 1, 'right');
  await tick(page, 9000);
  await page.waitForURL(/niveles\.html/);
  await page.keyboard.press('ArrowLeft'); await page.waitForURL(/menu\.html/);
});

await test('5. Terminar el desafío y redirección automática a "Selección de nivel"', async b => {
  const { page } = await open(b);
  await playQuiz(page, 1, 'right');
  await playWords(page, 1, 'right');
  assert.match(await page.textContent('#res-titulo'), /GANADO/);
  assert.match(await page.textContent('#res-countdown'), /8 s/);
  const navs = [];
  page.on('framenavigated', f => { if(f === page.mainFrame()) navs.push(f.url()); });
  await tick(page, 7000);
  assert.match(url(page), /^resultado\.html/, 'todavía espera');
  await tick(page, 1500);
  await page.waitForURL(/niveles\.html/);
  await tick(page, 5000);
  assert.strictEqual(navs.length, 1, 'redirige una sola vez');
  assert.ok((await state(page)).progress.levels[1].passed);
});

await test('6. Perder un nivel y verificar que se desbloquea el siguiente', async b => {
  const { page } = await open(b);
  await playQuiz(page, 1, 'wrong');
  await playWords(page, 1, 'wrong');
  assert.match(await page.textContent('#res-titulo'), /PERDIDO/);
  const s = await state(page);
  assert.strictEqual(s.progress.levels[1].passed, false);
  await go(page, 'niveles.html');
  assert.ok(await page.locator('a.lvl-row[data-n="2"]').count(), 'nivel 2 desbloqueado');
  assert.ok(await page.locator('.lvl-row.lost[data-n="1"]').count(), 'nivel 1 figura como perdido');
  assert.ok(await page.locator('.lvl-row.locked[data-n="3"]').count(), 'nivel 3 sigue bloqueado');
  await go(page, 'nivel-titulo.html?n=2');
  assert.match(url(page), /nivel-titulo\.html\?n=2/);
  // volver a perder no lo bloquea de nuevo
  await playQuiz(page, 1, 'wrong'); await playWords(page, 1, 'wrong');
  await go(page, 'niveles.html');
  assert.ok(await page.locator('a.lvl-row[data-n="2"]').count());
});

await test('7. Avanzar con el botón "Siguiente nivel"', async b => {
  const { page } = await open(b);
  await playQuiz(page, 1, 'wrong');
  await playWords(page, 1, 'wrong');
  assert.strictEqual(await page.textContent('#btn-sig'), 'SIGUIENTE NIVEL');
  await page.click('#btn-sig');
  await page.waitForURL(/nivel-titulo\.html\?n=2/);
  assert.strictEqual(await page.textContent('#nv-titulo'), 'UN DERECHO VULNERADO');
  await tick(page, 10000);
  assert.match(url(page), /nivel-titulo\.html\?n=2/, 'la redirección automática se canceló');
  // también desde "Selección de nivel"
  await go(page, 'niveles.html');
  assert.strictEqual(await page.getAttribute('#lvl-next', 'href'), 'nivel-titulo.html?n=2');
});

await test('8. Cambiar accesorios y que se mantengan', async b => {
  const { page } = await open(b, { user:'Tester', email:'t@test.com', progress:{ levels:played(3) } });
  await go(page, 'vestir.html');
  const before = await page.innerHTML('#avatar-box');
  await page.click('.ditem[data-cat="gorros"][data-key="gorraBordo"]');
  assert.notStrictEqual(await page.innerHTML('#avatar-box'), before, 'el personaje se actualiza');
  await page.click('.ditem[data-cat="mascotas"][data-key="gato"]');                 // nivel 3 terminado
  await page.click('.ditem[data-cat="bufandas"][data-key="bordo"]');
  await page.click('.ditem[data-cat="collares"][data-key="plata"]');               // excluye la bufanda
  let s = await state(page);
  assert.strictEqual(s.avatar.gorros, 'gorraBordo');
  assert.strictEqual(s.avatar.mascotas, 'gato');
  assert.strictEqual(s.avatar.collares, 'plata');
  assert.strictEqual(s.avatar.bufandas, undefined, 'bufanda y collar no se superponen');
  await page.click('.ditem[data-cat="gorros"][data-key="rana"]');                  // bloqueado (nivel 10)
  s = await state(page);
  assert.strictEqual(s.avatar.gorros, 'gorraBordo', 'una prenda bloqueada no se aplica');
  await page.click('.ditem[data-cat="gorros"][data-key="gorraBordo"]');            // tocar de nuevo = sacar
  assert.strictEqual((await state(page)).avatar.gorros, undefined);
  await page.click('.ditem[data-cat="gorros"][data-key="gorraBordo"]');
  // se mantiene al navegar y aparece en el tribunal
  await go(page, 'menu.html'); await go(page, 'vestir.html');
  assert.ok(await page.locator('.ditem.sel[data-key="gorraBordo"]').count());
  await go(page, 'juicio.html?n=1');
  const html = await page.innerHTML('[data-role="player-side"]');
  assert.ok(html.includes('#7a2333'), 'la gorra se ve en el tribunal');
});

await test('9. Consultar el manual de usuario', async b => {
  const { page } = await open(b);
  await go(page, 'menu.html');
  await page.click('.menu-manual'); await page.waitForURL(/manual\.html/);
  const titles = await page.$$eval('#man-scroll h2', h => h.map(x => x.textContent));
  assert.ok(titles.length >= 12, 'secciones: ' + titles.length);
  const txt = await page.textContent('#man-scroll');
  for(const k of ['20 segundos', 'Siguiente nivel'.toUpperCase(), 'desbloquea', 'Tiempo agotado', 'desafío final', 'VESTÍ A TU PERSONAJE', 'perdés'])
    assert.ok(txt.toLowerCase().includes(k.toLowerCase()), 'el manual explica: ' + k);
  const y0 = await page.$eval('.sb-thumb', e => e.style.transform);
  await page.$eval('#man-scroll', e => e.scrollTop = e.scrollHeight);
  let y1 = y0;
  for(let i = 0; i < 10 && y1 === y0; i++){ await tick(page, 200); y1 = await page.$eval('.sb-thumb', e => e.style.transform); }
  assert.notStrictEqual(y1, y0, 'la barra de desplazamiento acompaña');
});

await test('10. Completar el décimo nivel y ver la pantalla final', async b => {
  const { page } = await open(b, { user:'Tester', email:'t@test.com', progress:{ levels:played(9) } });
  await playQuiz(page, 10, 'right');
  await playWords(page, 10, 'right');
  assert.strictEqual(await page.textContent('#btn-sig'), 'VER FINAL');
  await page.click('#btn-sig'); await page.waitForURL(/fin\.html/);
  assert.match(await page.textContent('.title'), /CASOS CERRADOS/);
  assert.match(await page.textContent('#fin-box'), /Casos ganados: 10 de 10/);
  await go(page, 'niveles.html');
  assert.strictEqual(await page.getAttribute('#lvl-next', 'href'), 'fin.html');
  assert.deepStrictEqual(page.errors, []);
});

await test('11. Los botones no ejecutan acciones duplicadas', async b => {
  const { page } = await open(b);
  // doble respuesta en la misma pregunta
  await go(page, 'desafio.html?n=1');
  const opt = page.locator('.q-opt >> nth=0');
  await opt.dblclick();
  await page.keyboard.press('2'); await page.keyboard.press('Enter');
  const answered = await page.evaluate(() => document.querySelectorAll('.q-opt.right, .q-opt.wrong').length);
  assert.ok(answered <= 2, 'una sola respuesta marcada');
  const meta = await page.textContent('#q-meta');
  assert.ok(/PUNTOS (0|1\d\d)$/i.test(meta.trim()), 'puntaje sumado una vez: ' + meta);
  // doble clic en una flecha / botón: una sola navegación
  await go(page, 'nivel-titulo.html?n=1');
  const navs = [];
  page.on('framenavigated', f => { if(f === page.mainFrame()) navs.push(f.url()); });
  await page.dblclick('.btn-next', { force:true });
  await page.waitForURL(/nivel-desc/); await tick(page, 500);
  assert.strictEqual(navs.length, 1, 'navegaciones: ' + navs.length);
  // URL inexistente o nivel bloqueado → vuelve a la Selección de nivel
  await go(page, 'desafio.html?n=99'); await page.waitForURL(/niveles\.html/);
  await go(page, 'desafio.html?n=5');  await page.waitForURL(/niveles\.html/);
  await go(page, 'palabra.html?n=1');  await page.waitForURL(/niveles\.html/);
});

await test('12. Imágenes, estilos, fuentes y sin errores en consola', async b => {
  const { page } = await open(b, { user:'Tester', email:'t@test.com', progress:{ levels:played(10) } });
  const pages = ['registro.html','menu.html','config.html','soporte.html','ranking.html','manual.html','vestir.html','niveles.html',
    'nivel-titulo.html?n=3','nivel-desc.html?n=3','caso.html?n=3','juicio.html?n=3','desafio.html?n=3','fin.html'];
  for(const p of pages){
    await go(page, p); await tick(page, 300);
    const r = await page.evaluate(async () => {
      await document.fonts.ready;
      const imgs = [...document.images].filter(i => !i.complete || i.naturalWidth === 0).map(i => i.src);
      const css = [...document.styleSheets].length;
      const bg = getComputedStyle(document.querySelector('.stage')).backgroundImage;
      const faces = [...document.fonts];
      return { imgs, css, bg, broken: faces.filter(f => f.status === 'error').map(f => f.family), bebas: faces.some(f => f.family.includes('Bebas') && f.status === 'loaded') };
    });
    assert.deepStrictEqual(r.imgs, [], p + ' imágenes rotas');
    assert.strictEqual(r.css, 4, p + ' hojas de estilo');
    assert.ok(r.bg.includes('fondo.png'), p + ' fondo');
    assert.deepStrictEqual(r.broken, [], p + ' fuentes con error');
    assert.ok(r.bebas, p + ' fuente Bebas Neue');
  }
  await go(page, '../index.html');
  assert.deepStrictEqual(page.errors, [], 'errores: ' + page.errors.join(' | '));
});

console.log('\nDecisión Final · pruebas funcionales\n');
results.forEach(r => console.log(' ' + r[0] + ' ' + r[1]));
const failed = results.filter(r => r[0] === '✘').length;
console.log('\n' + (results.length - failed) + ' de ' + results.length + ' pruebas OK\n');
process.exit(failed ? 1 : 0);
})();

/* =========================================================
   boot.js · Arranque común de todas las pantallas
   - aplica idioma, escala, brillo y sonidos
   - protege pantallas que requieren registro o un nivel válido
   - navegación con las flechas del diseño (y teclas ← →)
   - evita navegaciones duplicadas (doble clic)
   ========================================================= */
window.DF = window.DF || {};

DF.nav = (function(){
  let leaving = false;     // ya se pidió cambiar de pantalla
  let locked = false;      // flechas deshabilitadas (durante el cuestionario / desafío)

  /* Nivel actual (?n=). Devuelve null si falta o no existe. */
  function level(){
    const n = parseInt(new URLSearchParams(location.search).get('n'), 10);
    const total = DF.levels ? DF.levels.length : 10;
    return (n >= 1 && n <= total) ? n : null;
  }

  /* Navega UNA sola vez aunque se llame varias veces */
  function go(page, n){
    if(leaving) return false;
    leaving = true;
    location.href = page + (n ? '?n=' + n : '');
    return true;
  }
  function replace(page, n){ leaving = true; location.replace(page + (n ? '?n=' + n : '')); }

  /* [data-level-link="archivo.html"] -> link con ?n=nivel */
  function linkLevels(){
    const n = level();
    document.querySelectorAll('[data-level-link]').forEach(a => { a.href = a.dataset.levelLink + (n ? '?n=' + n : ''); });
  }

  const arrows = () => document.querySelectorAll('.btn-back, .btn-next');

  /* Habilita / deshabilita las flechas generales */
  function lock(on){
    locked = !!on;
    arrows().forEach(a => {
      a.classList.toggle('nav-locked', locked);
      a.setAttribute('aria-disabled', locked ? 'true' : 'false');
      if(a.tagName === 'A'){
        if(locked){ if(a.hasAttribute('href')){ a.dataset.href = a.getAttribute('href'); a.removeAttribute('href'); } }
        else if(a.dataset.href){ a.setAttribute('href', a.dataset.href); }
      } else a.disabled = locked;
    });
  }
  const usable = el => el && !locked && !el.classList.contains('disabled') && !el.classList.contains('nav-locked') && el.offsetParent !== null;

  function bindArrows(){
    // Teclado: ← = flecha volver, → = flecha avanzar (si están habilitadas)
    document.addEventListener('keydown', e => {
      if(e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
      if(/^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || ''))) return;
      if(locked) return;
      const overlay = document.querySelector('.doc-overlay:not(.hidden)');
      const scope = overlay || document;
      let el = null;
      if(e.key === 'ArrowLeft') el = scope.querySelector('.btn-back');
      else if(e.key === 'ArrowRight' && !overlay) el = document.querySelector('.btn-next');
      if(usable(el)){ e.preventDefault(); el.click(); }
    });
    // Un solo cambio de pantalla por clic (evita duplicar acciones)
    document.addEventListener('click', e => {
      const a = e.target.closest('a');
      if(!a) return;
      if(a.classList.contains('nav-locked') || a.classList.contains('disabled') || !a.getAttribute('href')){ e.preventDefault(); return; }
      if(leaving){ e.preventDefault(); return; }
      leaving = true;
    }, true);
    // Si el navegador restaura la página desde la caché (botón atrás), se reactiva
    window.addEventListener('pageshow', ev => { if(ev.persisted) leaving = false; });
  }

  return { level, go, replace, linkLevels, lock, bindArrows, get locked(){ return locked; } };
})();

DF.toast = function(msg, ms){
  const stage = document.querySelector('.stage');
  let el = stage.querySelector('.toast');
  if(!el){ el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); stage.appendChild(el); }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(DF._toastT);
  DF._toastT = setTimeout(() => el.classList.remove('show'), ms || 2200);
};

DF.esc = s => String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));

/* opts.requiresUser: exige registro · opts.level: exige ?n= válido y desbloqueado */
DF.boot = function(fn, opts){
  opts = opts || {};
  document.addEventListener('DOMContentLoaded', () => {
    if(opts.requiresUser && !DF.store.state.user){ DF.nav.replace('registro.html'); return; }
    if(opts.level){
      const n = DF.nav.level();
      if(!n || !DF.progress.isUnlocked(n)){ DF.nav.replace('niveles.html'); return; }
    }
    DF.stage.init();
    DF.i18n.apply();
    DF.nav.linkLevels();
    DF.nav.bindArrows();
    DF.audio.bindGlobalClicks();
    if(fn) fn();
  });
};

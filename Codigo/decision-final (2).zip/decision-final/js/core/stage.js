/* =========================================================
   stage.js · Escala el escenario 1280x720 a la ventana y
   aplica Brillo y Gráficos de la configuración
   ========================================================= */
window.DF = window.DF || {};

DF.stage = (function(){
  const W = 1280, H = 720;
  let stage, shade;

  function fit(){
    if(!stage) return;
    const s = DF.store.state.settings;
    // "Gráficos": 1920 permite agrandar hasta 1.5x, 1280 deja el juego en tamaño base.
    const maxScale = s.res / W;
    const k = Math.min(window.innerWidth / W, window.innerHeight / H, maxScale);
    stage.style.transform = 'scale(' + k + ')';
    stage.style.imageRendering = s.res <= 1280 ? 'pixelated' : 'auto';
  }

  function applyBrightness(){
    if(!shade) return;
    const v = DF.store.state.settings.brightness;      // 0..100
    // 55 = brillo normal. Por debajo oscurece (capa negra), por encima aclara con filtro.
    if(v <= 55){ shade.style.opacity = (1 - v / 55) * .65; stage.style.filter = 'none'; }
    else { shade.style.opacity = 0; stage.style.filter = 'brightness(' + (1 + (v - 55) / 45 * .35) + ')'; }
  }

  function init(){
    stage = document.querySelector('.stage');
    if(!stage) return;
    shade = document.createElement('div');
    shade.className = 'stage-shade';
    stage.appendChild(shade);
    fit(); applyBrightness();
    window.addEventListener('resize', fit);
  }

  return { init, fit, applyBrightness };
})();

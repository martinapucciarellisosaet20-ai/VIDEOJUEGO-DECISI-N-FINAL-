/* =========================================================
   store.js · Estado persistente del juego (localStorage)
   Solo guarda y carga. La lógica de niveles está en progress.js.
   Si el navegador bloquea localStorage, el juego funciona en memoria.
   ========================================================= */
window.DF = window.DF || {};

DF.store = (function(){
  const KEY = 'df_decision_final_v1';
  const DEFAULTS = {
    user: null,
    email: null,
    settings: { volume: 70, brightness: 55, lang: 'es', res: 1920 },
    progress: { levels: {} },     // { "1": { played, passed, score, stars, attempts, last:{...} } }
    avatar: { piel: 'media', pelo: 'largo', varios: 'cadena' }
  };

  const clone = o => JSON.parse(JSON.stringify(o));
  function merge(base, extra){
    const out = clone(base);
    if(!extra || typeof extra !== 'object') return out;
    for(const k in extra){
      if(out[k] && typeof out[k] === 'object' && !Array.isArray(out[k]) && extra[k] && typeof extra[k] === 'object') out[k] = merge(out[k], extra[k]);
      else out[k] = extra[k];
    }
    return out;
  }

  /* Migra partidas guardadas con la versión anterior (progress.completed = solo niveles ganados) */
  function migrate(s){
    const old = s.progress && s.progress.completed;
    if(old){
      s.progress.levels = s.progress.levels || {};
      Object.keys(old).forEach(n => {
        if(!s.progress.levels[n]) s.progress.levels[n] = { played:true, passed:true, score: old[n].score || 0, stars: old[n].stars || 0, attempts:1 };
      });
      delete s.progress.completed;
    }
    // la versión anterior guardaba un avatar de "acc/ropa"; se reemplaza por el del prototipo
    if(s.avatar && ('acc' in s.avatar || 'ropa' in s.avatar)){
      s.avatar = { piel: s.avatar.piel || 'media', pelo: 'largo', varios: 'cadena' };
    }
    return s;
  }

  let state;
  try { state = migrate(merge(DEFAULTS, JSON.parse(localStorage.getItem(KEY)))); }
  catch(e){ state = clone(DEFAULTS); }

  function save(){ try { localStorage.setItem(KEY, JSON.stringify(state)); } catch(e){} }

  return {
    get state(){ return state; },
    update(fn){ fn(state); save(); },
    reset(){ state = clone(DEFAULTS); save(); }
  };
})();

/* Configuración: volumen, brillo, idioma, gráficos (todo se guarda y se aplica en vivo) */
DF.boot(function(){
  const s = DF.store.state.settings;
  const vol = document.getElementById('volumen');
  const bri = document.getElementById('brillo');
  const idi = document.getElementById('idioma');
  const gra = document.getElementById('graficos');
  vol.value = s.volume; bri.value = s.brightness; idi.value = s.lang; gra.value = String(s.res);

  vol.addEventListener('input', () => DF.store.update(st => st.settings.volume = +vol.value));
  vol.addEventListener('change', () => DF.audio.play('ok'));            // vista previa del volumen
  bri.addEventListener('input', () => { DF.store.update(st => st.settings.brightness = +bri.value); DF.stage.applyBrightness(); });
  idi.addEventListener('change', () => { DF.store.update(st => st.settings.lang = idi.value); DF.i18n.apply(); });
  gra.addEventListener('change', () => { DF.store.update(st => st.settings.res = +gra.value); DF.stage.fit(); });
}, { requiresUser:true });

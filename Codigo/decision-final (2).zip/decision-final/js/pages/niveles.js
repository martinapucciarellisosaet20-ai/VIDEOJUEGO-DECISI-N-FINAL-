/* =========================================================
   Selección de nivel
   - Estados: bloqueado 🔒, disponible, ganado (estrellas), perdido.
   - Terminar un nivel (ganado o perdido) desbloquea el siguiente.
   - Botón "SIGUIENTE NIVEL" al primer nivel desbloqueado sin jugar
     (o "VER FINAL" cuando ya se jugaron todos).
   ========================================================= */
DF.boot(function(){
  const t = DF.i18n.t;
  const P = DF.progress;
  const list = document.getElementById('lvl-list');
  const play = '<svg viewBox="0 0 24 28" aria-hidden="true"><path d="M3 2l19 12L3 26z" fill="#fbebd3"/></svg>';
  const lock = '<svg viewBox="0 0 24 28" aria-hidden="true" style="margin:0"><rect x="3" y="12" width="18" height="14" rx="2" fill="#fbebd3"/><path d="M7 12V8a5 5 0 0 1 10 0v4" fill="none" stroke="#fbebd3" stroke-width="3"/></svg>';
  const pending = P.nextPending();

  list.innerHTML = DF.levels.map(l => {
    const st = P.status(l.id);
    const res = P.result(l.id);
    const label = { available:t('nivelDisp'), won:t('nivelGanado'), lost:t('nivelPerdido'), locked:t('nivelBloq', { n:l.id - 1 }) }[st];
    const stars = res ? '<div class="stars">' + [0, 1, 2].map(k => '<span class="' + (k < res.stars ? '' : 'off') + '">★</span>').join('') + '</div>' : '';
    const inner = '<div class="dot">' + (st === 'locked' ? lock : play) + '</div>'
      + '<div class="tag">' + t('nivel', { n:l.id }) + '</div>'
      + '<div class="info">' + stars + '<div class="state">' + label + '</div></div>';
    const cls = 'lvl-row ' + st + (l.id === pending ? ' next' : '');
    return st === 'locked'
      ? '<div class="' + cls + '" data-n="' + l.id + '" aria-disabled="true">' + inner + '</div>'
      : '<a class="' + cls + '" data-n="' + l.id + '" href="nivel-titulo.html?n=' + l.id + '">' + inner + '</a>';
  }).join('');

  list.querySelectorAll('.lvl-row.locked').forEach(el => el.addEventListener('click', () => {
    DF.audio.play('bad'); DF.toast(t('nivelBloq', { n:+el.dataset.n - 1 }));
    el.classList.add('shake'); setTimeout(() => el.classList.remove('shake'), 400);
  }));

  // Botón "Siguiente nivel" (una vez que se jugó al menos un nivel)
  const btn = document.getElementById('lvl-next');
  if(P.playedCount() > 0){
    if(pending){ btn.href = 'nivel-titulo.html?n=' + pending; btn.textContent = t('sigNivel'); btn.classList.remove('hidden'); }
    else if(P.allPlayed()){ btn.href = 'fin.html'; btn.textContent = t('verFinal'); btn.classList.remove('hidden'); }
  }

  // Lleva a la vista el próximo nivel a jugar
  const target = list.querySelector('.lvl-row.next');
  if(target && target.offsetTop + target.offsetHeight > list.clientHeight) list.scrollTop = target.offsetTop - 20;
  DF.scrollbar(list, document.getElementById('lvl-track'));
}, { requiresUser:true });

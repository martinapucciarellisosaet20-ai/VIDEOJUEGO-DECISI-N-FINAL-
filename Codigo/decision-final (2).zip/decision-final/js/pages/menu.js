/* Menú principal */
DF.boot(function(){
  document.getElementById('menu-user').textContent = DF.store.state.user + ' · ' + DF.progress.totalScore() + ' ' + DF.i18n.t('pts');
}, { requiresUser:true });

/* Registro: valida correo y usuario y los guarda. */
DF.boot(function(){
  const form = document.getElementById('form-registro');
  const correo = document.getElementById('correo');
  const usuario = document.getElementById('usuario');
  const mC = document.getElementById('msg-correo');
  const mU = document.getElementById('msg-usuario');
  const s = DF.store.state;

  if(s.email) correo.value = s.email;
  if(s.user)  usuario.value = s.user;

  function check(){
    const okMail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(correo.value.trim());
    const u = usuario.value.trim();
    const okUser = u.length >= 3 && u.length <= 16;
    correo.classList.toggle('error', !okMail);
    usuario.classList.toggle('error', !okUser);
    mC.textContent = okMail ? '' : DF.i18n.t('errCorreo');
    mU.textContent = okUser ? '' : DF.i18n.t('errUsuario');
    return okMail && okUser;
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    if(!check()){ DF.audio.play('bad'); return; }
    DF.store.update(st => { st.email = correo.value.trim(); st.user = usuario.value.trim(); });
    location.href = 'menu.html';
  });
  [correo, usuario].forEach(i => i.addEventListener('input', () => { i.classList.remove('error'); }));
});
